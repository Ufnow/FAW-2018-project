package com.project.review.Models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "products")
public class Products {

    @Id
    @GenericGenerator(name="productor" , strategy="increment")
    @GeneratedValue(generator = "productor")
    private Integer id;
    private String name;
    private String category;
    private String description;
    private Double price;
    @OneToMany( fetch = FetchType.LAZY, mappedBy="product", cascade = CascadeType.REMOVE)
    private List<Reviews> reviews;
    @JsonIgnore
    public List<Reviews> getReviews() {
        return reviews;
    }

    public void setReviews(List<Reviews> reviews) {
        this.reviews = reviews;
    }

    public Products() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }
}
